package com.testautomation.Utility;

public class CommonDBFunctions {

}
