package com.testautomation.stepDef;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.testautomation.Utility.BrowserUtility;
import com.testautomation.Utility.DriverFactory;
import com.testautomation.Utility.PropertiesFileReader;
import com.testautomation.Utility.SeleniumActions;

import io.cucumber.java.Before;

public class Hooks extends ITestListenerImpl {

	PropertiesFileReader obj = new PropertiesFileReader();
	String stepName = "test";
	ExtentTest logInfo = null;
	
	private List<WebDriver> webDriverPool = Collection.synchronizedList(new ArrayList<WebDriver>());
	BrowserUtility bu = new BrowserUtility();
	SeleniumActions action = new SeleniumActions();
	
	@Before(order=0)
	public void createReportWithScenarioName(Scenario scenario) {
		getExtentTest().set(getExtent().createTest(scenario.getName()));
	}
	
	@Before(order=1)
	public void setupDefault() {
		Properties properties;
		try {
			properties = obj.getProperty();
			DriverFactory.getInstance().setDriver((bu.OpenBrowser("chrome", "https//:Flipkart.com")));
			WebDriver driver = DriverFactory.getInstance().getDriverDF();
			webDriverPool.add(driver);
			DriverFactory.getInstance().getDriverDF().manage().window().maximize();
			Thread.sleep(3000);
			
			LogingPage loginpage = new LoginPage();
			loginpage.enterUsername();
			loginpage.enterPassword();
			loginpage.clikSignIn();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@After
	public void close() {
		if(DriverFactory.getInstance().getDriverDF()!=null) {
			actions.closeBrowser();
		}
	}
	
}
