package com.testautomation.Utility;

import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;

import com.revamp.framework.runner.cucumber.RunScenariosFromTestCycle;

import io.cucumber.core.gherkin.vintage.internal.gherkin.StringUtils;

public class SeleniumActions  extends RunScenariosFromTestCycle {

	private static final Logger logger = Logger.getLogger(SeleniumActions.class);
	private static boolean status;
	public static int DELAYTIME = 3;
	public static int Maxtimetowait = 10;

	public String getBrowser() {
	Capabilities cap = ((RemoteWebDriver) getDriver()).getCapabilities();
	String browser = cap.getBrowserName().toLowerCase();
	return StringUtils.capitalize(browser);

	}
	
	public void navigateToUrl(String url) {
	try {
	if(url!=""|url!=null) {
	getDriver().navigate().to(url); 
	logger.info("Navigated to " + url);}
	else { throw new Exception("url empty");
	}
	} catch (Exception e) {
		logger.error("unable to navigate to url "+ url , e );
	}
	}
	
	public void closeBrowser() {
	String name = getBrowser();
	getDriver().close();
	logger.info( name + " Browser Closed Successfully");
	getDriver().quit();
	logger.info( name + " Browser Closed Completely");
	}
	
	
	
	
	
	
}
