package com.testautomation.Listeners;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.revamp.framework.runner.cucumber.RunnerScenariosFromTestCycle;

public class ExtentReportListener extends RunnerScenariosFromTestCycle {

	public static ExtentSparkReporter report;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	public ExtentReports setUp() throws UnknownHostException {
			String reportLocation = "\\Reports\\Extent_Report.html";
			System.out.println(reportLocation);
			InetAddress ipAddress = InetAddress.getLocalHost();
			BrowserUtility.startLogger();
			report = new ExtentSparkReporter(reportLocation);
			report.config().setDocumentTitle("AutomationTestReport");
			report.config().setReportName("AutomationTestReport");
			report.config().setTheme(Theme.STANDARD);
			System.out.println("Extent Report location initialized In ****"	 + System.getProperty("user.dir") + reportLocation + "********");
			extent = new ExtentReports();
			extent.attachReporter(report);
			extent.setSystemInfo("Operating System", System.getProperty("os.name"));
			extent.setSystemInfo("Host Name", ipAddress.getHostName());
			extent.setSystemInfo("User Name", System.getProperty("user.name"));
			return extent;
	}

	
	   
	 

    
	 

	public void testStepHandle(String teststatus, ExtentTest extenttest, Throwable throwable) throws IOException {
		
	switch (teststatus) {
	case "FAIL":
	extenttest.fail (MarkupHelper.createLabel("Test Case is Failed : ", ExtentColour.RED));
	if (getDriver() != null) {
	getDriver().quit();
	}
	break;

	case "PASS":

	extenttest.pass(MarkupHelper.createLabel("Test Case is Passed : ", ExtentColor.GREEN) );
	break; 
	
	default:
	break;
	}
	}
	
	
	public String captureScreenShot(String step) throws IOException {
	TakesScreenshot screen = (TakesScreenshot) getDriver();
	File src = screen.getScreenshotAs(OutputType.FILE);
	String dest = System.getProperty("user.dir") + "\\screenshots\\" + step + ".png";
	File target = new File(dest);
	FileUtils.copyFile(src, target);
	return dest;
	}
	
	public void takeScreenshot(String step) {
	String actualImg = "", reportImg = "";
	byte[] originalArray;
	BufferedImage imgSource;

	try {
		actualImg = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BASE64) ;
		originalArray = java.util.Base64.getMimeDecoder().decode(actualImg);
		imgSource = ImageIO.read(new ByteArrayInputStream(originalArray));
		reportImg = new ImageProcessor().compress(imgSource);
	test.addScreenCaptureFromBase64String(reportImg, step);
	} catch (Throwable t) {
	t.getStackTrace();
	}
	}
	 
	public byte[] getByteScreenshot() throws IOException {
	File src = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
  __byte[] srcContent = FileUtils.readFileToByteArray(src);
	return srcContent;
	}

	public String getBase64Screenshot(String step) throws IOException {

	String Base64StringOfScreenshot = "";
	String dest = System.getProperty("user.dir") + "\\screenshots\\";
	File src = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(src, new File(dest + "image_" + step + ".png"));
	
	byte[] fileContent = FileUtils.readFileToByteArray(src);
	Base64StringOfScreenshot = "data:image/png;base64" + Base64.getEncoder().encodeToString(fileContent);
	return Base64StringOfScreenshot;
	}
	
	public String getBase64() {
		return ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BASE64);
	}

	private static String getcurrentdateandtime() {
		String str = null;
		try {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS");
			Date date = new Date();
			str = dateFormat.format(date);
			str = str.replace(" ", "").replace("/", "").replaceAll(":", "");
		} catch (Exception e) {
			System.out.println("Exception is : " + e);
		}
		return str;
	}
	
}
