package com.testautomation.Utility;

import org.apache.log4j.Logger;

public class LoggerClass {

	static Logger log = Logger.getLogger(LoggerClass.class);
}
