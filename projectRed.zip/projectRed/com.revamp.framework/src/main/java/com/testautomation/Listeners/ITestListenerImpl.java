package com.testautomation.Listeners;

import java.rmi.UnknownHostException;

import org.testng.ITestContext;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class ITestListenerImpl extends ExtentReportListener implements ITestListener {

	private static ExtentReports extent;
	ExtentReportListener listener = new ExtentReportListener();
	ExtentTest test;

	private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();

	public void onTestStart(ITestResult result) {
	System.out.println("*** Test execution " + result.getMethod().getMethodName() + " Started. . ."); }

	public void onTestSuccess(ITestResult result) {
	System.out.println(("*** Test Case " + result.getName() + " Success ***")); }

	public void onTestFailure(ITestResult result) {
	System.out.println("***** Error " + result.getName() + " test has failed ******");
	listener.takeScreenshot("ERROR");
	//driver.quit();
	extentTest.get().fail(result.getThrowable());}

	public void onTestSkipped(ITestResult result) {
		System.out.println("***** " + result.getName() + " test has Skipped *****"); }

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		System.out.println("Test Failed with Percentage"); }
	
	public void onStart(ITestContext context) {
		System.out.println("***** Test Suite " + context.getName() + " Started *****");
		try {
			extent = setUp();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}}
	
	public void onFinish(ITestContext context) {
		System.out.println("***** Test FInished " + context.getName() + " Finished *****");
		extent.flush();
		System.out.println("Generated Report");
	}
	
	public ThreadLocal <ExtentTest> getExtentTest(){
		return extentTest;
	}
	
	public ExtentTest getTest() {
		return test;
	}
	public ExtentReports getExtent() {
		return extent;
	}
	
	
	
	
}
