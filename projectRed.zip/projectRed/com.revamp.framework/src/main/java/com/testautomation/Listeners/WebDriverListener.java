package com.testautomation.Listeners;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class WebDriverListener extends BrowserUtility implements WebDriverEventListener {

	ExtentReportListener et = new ExtentReportListener();
	
	public void beforeAlertAccept(WebDriver driver) {
		System.out.println("Alert Present");
		//User Action
	}
	
	public void afterAlertAccept(WebDriver driver) {
		System.out.println("Alert Accepted");
		//User Action
	}
	
	public void afterAlertDismiss(WebDriver driver) {
		System.out.println("Alert Dismissed");
		//User Action
	}
	
	public void beforeAlertDismiss(WebDriver driver) {
		System.out.println("Waiting for Alert");
		//User Action
	}

	public void beforeNavigationTo(String url, WebDriver driver) {
		
	}
	
	public void afterNavigationTo(String url, WebDriver driver) {
		
	}
	
	public void beforeNavigationBack(String url, WebDriver driver) {
		
	}
	
	public void afterNavigationBack(WebDriver driver) {
		
	}
	
	public void beforeNavigationForward(WebDriver driver) {
		
	}
	
	public void afterNavigationForward(WebDriver driver) {
		
	}
	
	public void beforeNavigationRefresh(WebDriver driver) {
		
	}
	
	public void afterNavigationRefresh(WebDriver driver) {
		
	}
	
	public void beforeFindBy(By by, WebElement element,WebDriver driver) {
		
	}
	
	public void afterFindBy(By by, WebElement element,WebDriver driver) {
		
	}
	
	public void beforeClickOn(WebElement element,WebDriver driver) {
		System.out.println("Try to click on " + element.toString());
	}
	
	public void afterClickOn(WebElement element,WebDriver driver) {
		System.out.println("Clicked on " + element.toString());
	}
	
	public void beforeChangeTheValueOf(WebElement element,WebDriver driver, CharSequence[] keysToSend) {
		
	}
	
	public void afterChangeTheValueOf(WebElement element,WebDriver driver, CharSequence[] keysToSend) {
		
	}
	
	public void beforeScript(String script,WebDriver driver) {
		
	}
	
	public void afterScript(String script,WebDriver driver) {
		
	}
	
	public void beforeSwitchToWindow(String windowName,WebDriver driver) {
		
	}
	
	public void afterSwitchToWindow(String windowName,WebDriver driver) {
		
	}
	
	public void onException(Throwable throwable, WebDriver driver) {
		
	}
	
	public <X> void beforeGetScreenShotAs(OutputType<X> target) {
		
	}
	public <X> void afterGetScreenShotAs(OutputType<X> target, X screenshot) {
	
	}
	
	public void beforeGetText(WebElement element, WebDriver driver) {
		System.out.println("Trying to get text from " + element.toString());
	}
	
	public void afterGetText(WebElement element, WebDriver driver) {
		System.out.println("Text from element " + element.toString());
	}
	
	//@override
	public void beforeNavigatingBack(WebDriver driver) {

	}
}