package com.testautomation.Utility;

import java.lang.System.Logger;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;

public class BrowserUtility {
	public static WebDriver driver;
	public static WebDriverWait ait = null;
	public static JavascriptExecutor excetor = null;
	public static Action action =  null;
	public static SeleniumActions selenium_Actions;
	public static Logger log;
	
	@Parameters(value = {"browserName"})
	public WebDriver OpenBrowser(String browserName, String url) throws InterruptedException {
		
		WebDriver driver = null;
		
		if (browserName.equals("chrome")) {
			
			//When testing in local, use these 2 lines
			
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/driver/chromedriver.exe");
			driver = new ChromeDriver();

			// When running in test jenkins, use the following lines

			/*	System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
				ChromeOptions chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--disable-web-security");
				chromeOptions.addArguments("--ignore-urlfetcher-cert-requests");
				chromeOptions.addArguments("--disable-renderer-backgrounding");
				chromeOptions.addArguments(“--disable-infobars");
				chromeOptions.addArguments("--headless");
				chromeOptions.addArguments("--disable-dev-shm-usage"); // overcome limited
				resource problems chromeOptions.addArguments("--no-sandbox"); // Bypass OS
				security model chromeOptions.addArguments("window-size=1200, 800");
				DesiredCapabilities cap = DesiredCapabilities.chrome();
				cap.setBrowserName("chrome"); chromeOptions.merge(cap); driver = new
				ChromeDriver(chromeOptions) ;
			*/	
				driver.manage().window().maximize();
				driver.get(url);
				Thread.sleep(5000);
				selenium_Actions = new SeleniumActions();
				wait = new WebDriverWait(driver, 120);
				actions = new Actions(driver);
				executor = ((JavascriptExecutor) driver);
				// startLogger();
				return driver;

				} else if (browserName.equalsIgnoreCase("MicrosoftEdge")) {

				/*System.setProperty("webdriver.edge.driver”, System.getProperty
				driver = new EdgeDriver();

				ariver .manage() .window().maximize()

				driver.get(url);

				Thread. sleep(5ee0) ;

				selenium_Actions = new SeleniumActions();
				wait = new WebDriverWait(driver, 12@);
				actions = new Actions(driver);

				executor = ((JavascriptExecutor) driver);
				EdgeOptions eoptions = new EdgeOptions();
				eoptions.addArguments(" -inprivate");
				driver = new EdgeDriver(eoptions) ;

				return driver; */

				} else if (browserName.equals("IE")) {
					
					/*
				System.setProperty("webdriver.ie.driver", System. getProperty("us
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(CapabilityType. UNEXPECTED ) ALERT_BEHAV
				_ Capabilities. setCapability(InternetExplorerDriver. INTRODUCE_FLAK
				papi tities. setCapability(CapabilityType. ACCEPT_SSL_ CERTS, ith
				.setCapability(" ignoreZoomSetting", true);
				(("requireWindowFo

				 */
					
				}
				 else if (browserName.equals("Firefox")) {
					  }
				     
				  return null;
				      
	}
			
			
		public static void startLogger() {
			log = Logger.getLogger(LoggerClass.class);
			PropertyConfigurator.configure("resources/log4j.properties");
		}	
			
			
			
			
		}
		
		
		
		
		
		
		
		

