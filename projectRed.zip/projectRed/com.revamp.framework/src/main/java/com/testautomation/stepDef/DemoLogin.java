package com.testautomation.stepDef;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Capabilities;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.testautomation.Listeners.ITestListenerImpl;
import com.testautomation.Utility.BrowserUtility;
import com.testautomation.Utility.PropertiesFileReader;

import io.cucumber.java.en.Given;

public class DemoLogin extends ITestListenerImpl {

	PropertiesFileReader obj = new PropertiesFileReader();
	ExtentTest logInfo = null;
	
	BrowserUtility bu = new BrowserUtility();
	
	public String getBrowser() {
		Capabilities cap = ((RemoteWEbDriver) getDriver()).getCapabilities();
		String browser = cap.getBrowserName().toLowerCase();
		return StringUtils.capitalize(browser);
		
		@Given("User tyring to login")
		public void invokeapp() {
			Properties properties;
		try {
			properties = obj.getProperty();
			logInfo = getExtentTest().get().createNode(new GherkinKeyword("Given"), "User tyring to login");
			
			loginapp myloginapp = new loginapp();
			myloginapp.login();
			logInfo.pass("ENtering into the login page", MediaEntityBuilder.createScreenCaptureFromBase64String(getBase64().build()));
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}	
		}
		
	}
	

