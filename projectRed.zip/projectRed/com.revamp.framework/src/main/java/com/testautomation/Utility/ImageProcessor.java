package com.testautomation.Utility;

public class ImageProcessor {

}
