package com.blackred.fwname;

public class DownloadCucucmberScenariosFromJira {

	static String jqlQuery = System.getProperty("jql");
	static String downloadedStoriesDir = System.getProperty("downloadedStoriesDir");
	
	@Test
	public void downloadScenarios() {
		try {
			String output = CucumberJiraIntegrationServices.downloadCucucmberScenariosFromJira(jqlQuery, downloadedStoriesDir);
		System.out.println(output);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
}
