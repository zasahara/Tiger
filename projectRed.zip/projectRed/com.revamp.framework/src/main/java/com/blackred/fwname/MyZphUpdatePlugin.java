package com.blackred.fwname;

import io.cucumber.messages.Messages.TestCaseFinished;

public class MyZphUpdatePlugin extends ZphUpdatePlugin {

	@Override
	protected void updateZphAfterTest(TestCaseFinished event, long testExecutionId, int statusCode) {
		super.updateZphAfterTest(event, testExecutionId, statusCode);
		System.out.println("======= Can add additional Zph update actions for" + event.getTestCase().getName());
		
	}
	
	@Override
	protected void updateZphAfterTestStep(TestCaseFinished event, long stepResultId, int statusCode, String comment) {
		super.updateZphAfterTestStep(event, stepResultId, statusCode, comment);
		System.out.println("======= Can add additional Zph  step update actions for" + event.getTestCase().getName());
		
	}
	
	
}
