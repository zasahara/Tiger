package com.blackred.fwname;

public class CreateZphTestForCucumberScenarios {
	
	static String jqlQuery = System.getProperty("jql");
	static boolean updateExistingZphTests = System.getProperty("update","Y").equalsIgnoreCase("Y");
	static boolean createTestForExampleRow = System.getProperty("exampleAsTest","Y").equalsIgnoreCase("Y");
	
	@Test
	public void creteZphTests() {
		try {
			String output = CucumberJiraIntegrationServices.createZphForGHerkin(jqlQuery, updateExistingZphTest, createTestForExampleRow);
		System.out.println(output);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
