package com.revamp.framework.runner.cucumber;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;

import com.testautomation.Utility.BrowserUtility;
import com.testautomation.Utility.DriverFactory;
import com.testautomation.Utility.PropertiesFileReader;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/resources",
tags = "",
glue = {"StepDef"},
publish = true,
plugin = {
	"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
	"junit:test-results/reports/JunitReport.xml"
})


public class RunScenariosFromTestCycle extends AbstractTestNGCucumberTests {

	private List<WebDriver> webDriverPool = Collections.synchronizedList(new ArrayList<WebDriver>());
	
	BrowserUtility bu = new BrowserUtility();
	PropertiesFileReader obj = PropertiesFileReader();
	
	@Override
	@DataProvider(parallel = false)
	public Object[][] scenarios(){
		return super.scenarios();
	}
	
	public WebDriver getDriver() {
		return DriverFactory.getInstance().getDriverDF();
	}
	
	
	
	
}
